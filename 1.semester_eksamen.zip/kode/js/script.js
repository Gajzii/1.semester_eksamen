// Scroll functions
function scrollToId(){
  $(document).ready(function(){
    $("a.scrollLink").click(function(event){
      event.preventDefault();
      $("html, body").animate({scrollTop: $($(this).attr("href")).offset().top}, 500);
    });
  });
  jQuery(document).ready(function(){
    var offset = 220;
    var duration = 500;
    jQuery(window).scroll(function(){
      if(jQuery(this).scrollTop() > offset){
        jQuery('.scroll-to-top').fadeIn(duration);
      } else {
        jQuery('.scroll-to-top').fadeOut(duration);
      }
    });
    jQuery('.scroll-to-top').click(function(event){
      event.preventDefault();
      jQuery('html, body').animate({scrollTop: 0}, duration);
      return false;
    })
  });
}
// Scroll functions end
// Slideshow
var slideIndex = 1;
showSlides(slideIndex);
function plusSlides(n) {
  showSlides(slideIndex += n);
}
function currentSlide(n) {
  showSlides(slideIndex = n);
}
function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1} 
  if (n < 1) {slideIndex = slides.length};
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block"; 
  dots[slideIndex-1].className += " active";
}
// Slideshow end